<?php
/**
 * @package Mega Main Menu Mod
 * @version 1.1.0
 * Plugin Name: Mega Menu 
 * Plugin URI: http://wowothemes.com
 * Description: Add support to mega menu creation, support to icons and other options.
 * Version: 1.0
 * Author: WoWoThemes 
 * Author URI: http://wowothemes.com/
 */
	include_once( 'plugin_framework/primary_class.php' );
?>